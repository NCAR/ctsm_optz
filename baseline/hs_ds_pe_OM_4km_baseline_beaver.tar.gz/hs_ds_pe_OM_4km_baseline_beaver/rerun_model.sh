#!/bin/bash

./update_field.yifan.sh
./case.submit
