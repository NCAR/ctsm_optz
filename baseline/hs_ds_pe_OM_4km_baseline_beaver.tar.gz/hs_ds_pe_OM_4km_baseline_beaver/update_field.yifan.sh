#!/bin/bash

# scripts
script="./xmlchange"
query_script="./xmlquery"

# input data
domain_dir="/glade/work/yifanc/NNA/optmz/input/basin_level/domain"
domain_file="domain.beaver.pe.4km.c210719.cdf5.nc"

${script} LND_DOMAIN_PATH=${domain_dir}
${script} LND_DOMAIN_FILE=${domain_file}
${script} ATM_DOMAIN_PATH=${domain_dir}
${script} ATM_DOMAIN_FILE=${domain_file}

${script} STOP_N=7
${script} STOP_OPTION=nyears

${script} RUN_STARTDATE=2002-09-01
${script} DOUT_S_SAVE_INTERIM_RESTART_FILES=TRUE
${script} ATM_NCPL=72
${script} JOB_QUEUE="economy"
${script} PROJECT="UCUB0089"

${script} NTASKS=-2
${script} NTASKS_ATM=-1
${script} NTASKS_ESP=1
${script} NTASKS_IAC=1
${script} NTASKS_PER_INST_ATM=36
${script} NTASKS_PER_INST_ESP=1
${script} NTASKS_PER_INST_IAC=1

./case.setup --reset
./case.build --clean-all
./case.build

${query_script} LND_DOMAIN_PATH,LND_DOMAIN_FILE,ATM_DOMAIN_PATH,ATM_DOMAIN_FILE,STOP_N,STOP_OPTION,RUN_STARTDATE,ATM_NCPL
